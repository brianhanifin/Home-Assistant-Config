export default {
    group: false,
    color_wheel: true,
    persist_features: false,
    brightness: true,
    color_temp: true,
    white_value: true,
    color_picker: true,
};
