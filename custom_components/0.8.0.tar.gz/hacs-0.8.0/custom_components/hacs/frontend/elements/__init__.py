"""Initialize frontend elements."""
