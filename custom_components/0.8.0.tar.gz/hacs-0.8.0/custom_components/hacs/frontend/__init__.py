"""Initialize frontend objects."""
